import React from 'react';


const ChatHeader = ({ handleTerminateChat }) => {
    return (
        <div className="chat-header">
            <span className="chat-title">Chat With Us </span>
            <button className="close-btn" onClick={handleTerminateChat}>
                <i className="fas fa-times"></i>
            </button>
        </div>
    );
};

export default ChatHeader;
