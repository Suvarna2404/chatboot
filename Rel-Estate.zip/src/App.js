// import Chatbot from './Components/Chatbot';
import ChatContainer from './Components/ChatContainer';

import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        {/* <Chatbot /> */}
        <ChatContainer />

      </header>
    </div>
  );
}

export default App;
